"use strict";

var commonLibraryJsVersion = "0.0.1";

// Element to attach events to
var eventElement = document;


var socketTimeout_ms = 600000;

var screenNotification = true;
var soundNotification = true;
var screenNotificationSetting = true;
var soundNotificationSetting = true;


var currentAudio = -1;
var defaultSoundTimeout = 15000;
var SoundTimerID = null;

//Image timeout variables
var timerID = null;
var defaultTimout = 3000;

//var socketList = [];
var socketItems = 0;

var telemLists = [];
var socketList = [];
var logFileName = "";
var msgBuffer = "";

var pluginsInitialized=false;

/**
*   Print text to console with a timestamp.
*   @private
*   @param {string} msg - Text to be displayed on console
**/
function log(msg) {
    console.log(timeStamp() + " " + msg);
}

/** 
* Create a new socket connection to the specified IP and port. 
* @private
* @param {Object} devices - Array of devices for this connection
* @param {string} ip - IP Address for socket connection
* @param {string} port - Port for socket connection
* @param {string} led - Name of HTML DOM element to show connections status
* @returns {Object} New socket connection
**/
function createSocketObject(devices, ip, port, led) {
	var socketObject = new Object();
	socketObject.devices = devices;
	socketObject.ip = ip;
	socketObject.port = port;
	socketObject.connected = false;
	socketObject.connecting = false;
	socketObject.led = led;
	socketObject.socket = null;
	socketObject.url = null;
	socketObject.timerID = null;
	socketObject.timeoutID = null;
	socketObject.startTimer = function (value)
	{
		if ((socketObject.timeoutID != null) && (socketObject.timeoutID != undefined))
		{
			console.log("Clearing timeout for " + socketObject.url + " socketObject.timeoutID:" + socketObject.timeoutID);
			clearTimeout(socketObject.timeoutID);
			socketObject.timeoutID = null;
		}
		socketObject.timeoutID = setTimeout(
			function()
			{ 
				console.log("------- Socket Timeout Closing " + socketObject.url + " ID:" + socketObject.timeoutID + "----------------");
				socketObject.socket.close();
				updateConnected(socketObject.url, false);
				socketObject.connected = false;
				socketObject.connecting = false;
			}, 
			socketTimeout_ms
		);
//		console.log("--------------------------------------- Starting Timer " + socketObject.timeoutID + "-------------------------------------------------------------")
 	};

	return socketObject;
}

var printed = false;

function updateListObject(device, plugin, name, value) {
    
    var found = false;

    // Look for table row in table
    $("[id=\"infoTable_" + plugin + "\"] > tbody  > tr").each(function() {
        // if found just update the values
        if ($(this).find("td").eq(0).html() == name)
        {
            found = true;
            $(this).find("td").eq(1).html(value.trim());
        }
    });
    // Add new table row
    if (!found)
    {
        $("[id=\"infoTable_" + plugin + "\"]").append("<tr><td>" + name + "</td><td>" + value.trim() + "</td></tr>");
    }

    if (name.toUpperCase() == "ENABLED") RefreshHeaderStatus (plugin, value);
}

function updateStateObject(device, plugin, name, value) {
    var found = false;
    // Look for table row in table
    $("[id=\"stateTable_" + plugin + "\"] > tbody  > tr").each(function() {
        // if found just update the values
        if ($(this).find("td").eq(0).html() == name)
        {
            found = true;
            $(this).find("td").eq(1).html(value.trim());
        }
        
    });
    // Add new table row
    if (!found)
    {
        $("[id=\"stateTable_" + plugin + "\"]").append("<tr><td>" + name + "</td><td>" + value + "</td></tr>");
    }
}

function updateStatusObject(device, plugin, name, value) {
    $("div[id=\"pluginHeader_" + plugin + "\"] > .pluginState").html(value.trim());
}


function updateMessagesObject(device, plugin, id, type, subtype, count, lastTimestamp, averageInterval) {
    var found = false;
    // Look for table row in plugin table
    $("[id=\"messagesTable_" + plugin + "\"] > tbody  > tr").each(function() {
        // if found just update the values
        if (($(this).find("td").eq(1).html() == type) && ($(this).find("td").eq(2).html() == subtype))
        {
            found = true;
            $(this).find("td").eq(3).html(count);
            $(this).find("td").eq(4).html(lastTimestamp);
            $(this).find("td").eq(5).html(averageInterval);
        }
        
    });
    // Add new table row
    if (!found)
    {
        var tableRow = "<tr><td>" + plugin + "</td><td>" + type + "</td><td>" + subtype + "</td><td>" + count + "</td><td>" + lastTimestamp + "</td><td>" + averageInterval + "</td></tr>"
        $("[id=\"messagesTable_" + plugin + "\"]").append(tableRow);
    }

    // Update the main table
    var table = $("[id=messagesTable]").DataTable();
    var indexes = table.rows().eq( 0 ).filter( function (rowIdx) {
        return ((table.cell( rowIdx, 0 ).data() === plugin) && (table.cell( rowIdx, 1 ).data() === type) && (table.cell( rowIdx, 2 ).data() === subtype)) ? true : false;
    } );
    // Check for existing rows
    if (indexes.length > 0)
    {
            // Update values
            for (var i=0; i < indexes.length; i++)
            {
                var rowData = table.row(indexes[i]).data();
                rowData[3] = count;
                rowData[4] = lastTimestamp;
                rowData[5] = averageInterval;
                table.row(indexes[i]).data(rowData).draw();
            }
    }
    // No rows with that message so create one
    else 
    {
       table.row.add([
            plugin,
            type,
            subtype,
            count,
            lastTimestamp,
            averageInterval
        ]).draw();        
    }
}

function updateConfigurationObject(device, plugin, name, value, defaultValue, Description) {
    var found = false;
    // Look for table row in table
    $("[id=\"configsTable_" + plugin + "\"] > tbody  > tr").each(function() {
        // if found just update the values
        if ($(this).find("td").eq(0).html() == name)
        {
            found = true;
            $(this).find("td").eq(1).html(value);
            $(this).find("td").eq(2).html(defaultValue);
            $(this).find("td").eq(3).html(Description);
            // TODO Can we add abreak here?
        }
        
    });
    // Add new table row
    if (!found)
    {
        $("[id=\"configsTable_" + plugin + "\"]").append("<tr><td>" + name + "</td><td>" + value + "</td><td>" + defaultValue + "</td><td>" + Description + "</td></tr>");
    }
}

/**
*   Message Handler. All incoming messages are sent to this handler.
*   @private
*   @param {string} - Incoming message
**/
function messageHandler(msg)
{
//	log(msg);
	// Strip control characters
	msg = msg.replace(/[\x00-\x1F\x7F-\x9F]/g, "");
	var json_obj = JSON.parse(msg);

	if (json_obj.header.type.toUpperCase() === "TELEMETRY") {
	    if (json_obj.header.subtype.toUpperCase() === "LIST") {
	        handleListMessage(json_obj.payload);
	    }
	    else if (json_obj.header.subtype.toUpperCase() === "STATUS") {
	        handleStatusMessage(json_obj.payload);
	    }
	    else if (json_obj.header.subtype.toUpperCase() === "STATE") {
	        handleStateMessage(json_obj.payload);
	    }
	    else if (json_obj.header.subtype.toUpperCase() === "CONFIG") {
	        handleConfigMessage(json_obj.payload);
	    }
	    else if (json_obj.header.subtype.toUpperCase() === "MESSAGES") {
	        handleMessagesMessage(json_obj.payload);
	    }
	} else {
	    console.log("Message:" + msg);
	}
}

function removePlugins()
{
	var pluginList = document.getElementById("pluginList");
    if (pluginList != null && pluginList != undefined) {
		pluginList.innerHTML = "";
		 pluginsInitialized = false;
    }
    $("[id=messagesTable]").DataTable().clear().draw();
}

function handleListMessage(msgData) {
    console.log("Found Telemetry - List Message");
    console.log(msgData);
    var plugins = Object.keys(msgData);
    for (var j = 0; j < plugins.length; j++) {
        var pluginObj = $(".plugin[data-target=\"" + plugins[j] + "\"]");
        if (pluginObj.length <= 0) {
            var pluginList = document.getElementById("pluginList");
            pluginList.innerHTML += "<div class='plugin' data-target='" + plugins[j] + "'></div>";
            new PluginDisplay($(".plugin[data-target=\"" + plugins[j] + "\"]")[0], msgData[plugins[j]]);
        } else {
            var registerArray = [];
            var object = msgData[plugins[j]];
            var jsonPosArray = [];
            var pos = 0;
            var info = "";
            var prefix = "";
            while (typeof (object) == "object") {
                var items = Object.keys(object);
                for (var i = pos; i < items.length; i++) {
                    if (typeof (object[items[i]]) == "object") {
                        jsonPosArray.push({ obj: object, pos: i + 1, prefix: prefix });
                        prefix += items[i] + "->";
                        object = object[items[i]];
                        items = Object.keys(object);
                        pos = 0;
                        i = 0;
                        break;
                    } else {
                        updateListObject("V2IHUB", plugins[j], prefix + items[i], object[items[i]]);
                    }
                }

                if (object == msgData[plugins[j]]) {
                    break;
                }

                if (i >= items.length) {
                    var infoArray = jsonPosArray.pop();
                    object = infoArray.obj;
                    pos = infoArray.pos;
                    prefix = infoArray.prefix.replace(new RegExp(items[i] + "->"), "");
                }
            }
        }
    }
}

function handleConfigMessage(msgData) {
    console.log("Found Config Message");
    var plugins = Object.keys(msgData);
    for (var j = 0; j < plugins.length; j++) {
        var pluginObj = $(".plugin[data-target=\"" + plugins[j] + "\"]");
        if (pluginObj.length <= 0) {
            var pluginList = document.getElementById("pluginList");
            pluginList.innerHTML += "<div class='plugin' data-target='" + plugins[j] + "'></div>";
            new PluginDisplay($(".plugin[data-target=\"" + plugins[j] + "\"]")[0], msgData[plugins[j]]);
        } else {
            var registerArray = [];
            var object = msgData[plugins[j]];
            var jsonPosArray = [];
            var pos = 0;
            var info = "";
            var prefix = "";

            var configItem = null;
            var val = null;
            var defaultVal = null;
            var description = null;

            while (typeof (object) == "object") {
                var items = Object.keys(object);
                for (var i = pos; i < items.length; i++) {
                    if (typeof (object[items[i]]) == "object") {
                        jsonPosArray.push({ obj: object, pos: i + 1, prefix: prefix });
                        prefix += items[i] + "->";
                        configItem = items[i];
                        object = object[items[i]];
                        items = Object.keys(object);
                        pos = 0;
                        i = 0;
                        break;
                    } else {
                        var key = items[i].toUpperCase();
                        if (key == "VALUE") {
                            val = object[items[i]];
                        } else if (key == "DEFAULTVALUE") {
                            defaultVal = object[items[i]];
                        } else if (key == "DESCRIPTION") {
                            description = object[items[i]];
                        }
                    }
                }
                if (object == msgData[plugins[j]]) {
                    break;
                }

                if (i >= items.length) {
                    var infoArray = jsonPosArray.pop();
                    object = infoArray.obj;
                    pos = infoArray.pos;
                    prefix = infoArray.prefix.replace(new RegExp(items[i] + "->"), "");
                    updateConfigurationObject("V2IHUB", plugins[j], configItem, val, defaultVal, description);
                }
            }
        }
    }
    return;
}

function handleStateMessage(msgData) {
//    console.log("Found Telemetry - State Message");
    var plugins = Object.keys(msgData);
    for (var j = 0; j < plugins.length; j++) {
        var pluginObj = $(".plugin[data-target=\"" + plugins[j] + "\"]");
        if (pluginObj.length <= 0) {
            var pluginList = document.getElementById("pluginList");
            pluginList.innerHTML += "<div class='plugin' data-target='" + plugins[j] + "'></div>";
            new PluginDisplay($(".plugin[data-target=\"" + plugins[j] + "\"]")[0], msgData[plugins[j]]);
        } else {
            var registerArray = [];
            var object = msgData[plugins[j]];
            var jsonPosArray = [];
            var pos = 0;
            var info = "";
            var prefix = "";
            while (typeof (object) == "object") {
                var items = Object.keys(object);
                for (var i = pos; i < items.length; i++) {
                    if (typeof (object[items[i]]) == "object") {
                        jsonPosArray.push({ obj: object, pos: i + 1, prefix: prefix });
                        prefix += items[i] + "->";
                        object = object[items[i]];
                        items = Object.keys(object);
                        pos = 0;
                        i = 0;
                        break;
                    } else {
                        updateStateObject("V2IHUB", plugins[j], prefix + items[i], object[items[i]]);
                    }
                }

                if (object == msgData[plugins[j]]) {
                    break;
                }

                if (i >= items.length) {
                    var infoArray = jsonPosArray.pop();
                    object = infoArray.obj;
                    pos = infoArray.pos;
                    prefix = infoArray.prefix.replace(new RegExp(items[i] + "->"), "");
                }
            }
        }
    }
}

function handleMessagesMessage(msgData) {
//    console.log("Found Telemetry - Messages Message");
    var plugins = Object.keys(msgData);
    for (var j = 0; j < plugins.length; j++) {
        var pluginObj = $(".plugin[data-target=\"" + plugins[j] + "\"]");
        if (pluginObj.length <= 0) {
            var pluginList = document.getElementById("pluginList");
            pluginList.innerHTML += "<div class='plugin' data-target='" + plugins[j] + "'></div>";
            new PluginDisplay($(".plugin[data-target=\"" + plugins[j] + "\"]")[0], msgData[plugins[j]]);
        } else {
            var registerArray = [];
            var object = msgData[plugins[j]];
            var jsonPosArray = [];
            var pos = 0;
            var info = "";
            var prefix = "";
            if (Array.isArray(msgData[plugins[j]])) {
                for (var l = 0; l < msgData[plugins[j]].length; l++) {
                    object = msgData[plugins[j]][l];
                    var id = null;
                    var type = null;
                    var subtype = null;
                    var count = null;
                    var lastTimestamp = null;
                    var averageInterval = null;
                    while (typeof (object) == "object") {
                        var items = Object.keys(object);
                        for (var i = pos; i < items.length; i++) {
                            if (typeof (object[items[i]]) == "object") {
                                jsonPosArray.push({ obj: object, pos: i + 1, prefix: prefix });
                                prefix += items[i] + "->";
                                object = object[items[i]];
                                items = Object.keys(object);
                                pos = 0;
                                i = 0;
                                break;
                            } else {
                                var key = items[i].toUpperCase();
                                if (key == "ID") {
                                    id = object[items[i]];
                                } else if (key == "TYPE") {
                                    type = object[items[i]];
                                } else if (key == "SUBTYPE") {
                                    subtype = object[items[i]];
                                } else if (key == "COUNT") {
                                    count = object[items[i]];
                                } else if (key == "LASTTIMESTAMP") {
                                    lastTimestamp = object[items[i]];
                                } else if (key == "AVERAGEINTERVAL") {
                                    averageInterval = object[items[i]];
                                }
                            }
                        }

                        if (object == msgData[plugins[j]][l]) {
                            break;
                        }

                        if (i >= items.length) {
                            var infoArray = jsonPosArray.pop();
                            object = infoArray.obj;
                            pos = infoArray.pos;
                            prefix = infoArray.prefix.replace(new RegExp(items[i] + "->"), "");
                        }
                    }
                    updateMessagesObject("V2IHUB", plugins[j], id, type, subtype, count, lastTimestamp, averageInterval);
                }
            }
        }
    }
}

function handleStatusMessage(msgData) {
//    console.log("Found Telemetry - Status Message");
    var plugins = Object.keys(msgData);
    for (var j = 0; j < plugins.length; j++) {
        updateStatusObject("V2IHUB", plugins[j], "Status", msgData[plugins[j]]);
    }
}

// Utilities

function generateUUID(){
    var d = new Date().getTime();
    if(window.performance && typeof window.performance.now === "function"){
        d += performance.now(); //use high-precision timer if available
    }
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x3|0x8)).toString(16);
    });
    return uuid;
}


/**
*   Generate timestamp for the given time.
*   @param {Date} time - Given time
*   @returns {string} Text containing the hours, minutes, seconds, and milliseconds of given time
**/
function timeStamp(time)
{
	if (time == null)
	    time = new Date();
	var timeString = "";
    
	var hours = time.getHours().toString();
	if (hours.length == 1) {
	    hours = "0" + hours;
	}

	var minutes = time.getMinutes().toString();
	if (minutes.length == 1) {
	    minutes = "0" + minutes;
	}

	var seconds = time.getSeconds().toString();
	if (seconds.length == 1) {
	    seconds = "0" + seconds;
	}

	var timeString = hours + ":" + minutes + ":" + seconds;// + "." + time.getMilliseconds();
	return timeString;
}

function fullTimeStamp()
{
	var time = new Date();
	var timeString = "";
    
	var hours = time.getHours().toString();
	if (hours.length == 1) {
	    hours = "0" + hours;
	}

	var minutes = time.getMinutes().toString();
	if (minutes.length == 1) {
	    minutes = "0" + minutes;
	}

	var seconds = time.getSeconds().toString();
	if (seconds.length == 1) {
	    seconds = "0" + seconds;
	}

	var timeString = time.toLocaleDateString() + "  " + hours + ":" + minutes + ":" + seconds + "." + time.getMilliseconds();
	return timeString;
}

function trimLineEndings(input)
{
	return input.replace(/(\r\n|\n|\r)/gm,"");
}

// Socket Functions ------------------------------------------------------
function sendCommand(msg)
{

	var sent = false;
	var tokens = msg.split(";");
	var dev = tokens[0];

//    msg=msg+"\n";
//  	encode=window.btoa(msg);
	console.log("----------------------- Sending:" + tokens[1]);
	tokens[1] = "\x02" + tokens[1] + "\x03";
//	var encode = window.btoa(msg);/*(tokens[1]);*/
    var encode = window.btoa(tokens[1]);

    var tempList = socketList;

  	// Look for socket
  	for (var j = 0; j < tempList.length; j++) {
		var tempObj = tempList[j];
		for (var k = 0; k < tempObj.devices.length; k++) {
			var tempDevice = tempObj.devices[k];
			if (dev.toUpperCase().indexOf(tempDevice.toUpperCase()) === 0)
			{
				if (tempObj.socket.readyState === tempObj.socket.OPEN)
				{
					tempObj.socket.send(encode);
					sent = true;
					break;
				}
				else 
				{
					updateConnected(tempObj.url, false);
				}
			}
		}
	} 
//	if (!sent)
//	{
//		console.log("Could not send command - Device not found:" + msg);
//	}
}

/**
*   @private
**/
function updateConnected(url, connected)
{
	for (var j = 0; j < socketList.length; j++) {
		var tempObj = socketList[j];
		// If found update all objects in that telemetry array
		if (tempObj.url == url) 
		{
			tempObj.connected = connected;
			if (connected)
			{
				if(tempObj.timerID) { /* a setInterval has been fired */
	   				window.clearInterval(tempObj.timerID);
	   				tempObj.timerID=0;
 				}
                var led = document.getElementById(tempObj.led);
                if (led != null && led != undefined) {
				    led.setAttribute('src', '../images/Battelle/WhiteLockup.png');
                }

            	var event = new CustomEvent("connect", {
					detail: {
						time: new Date(),
					},
				});
				eventElement.dispatchEvent(event);
			}
			else
			{
				if (!tempObj.timerID) {
  					tempObj.timerID=setInterval(function() { connect(url) }, 10000);
  									// Set no data for devices
                    var led = document.getElementById(tempObj.led);
                    if (led != null && led != undefined) {
					    led.setAttribute('src', '../images/Battelle/GrayLockup.png');
                    }
					for (var j = 0; j < tempObj.devices.length; j++) {
					    noData(tempObj.devices[j]);
					}
					console.log("Disconnected...........");
					removePlugins();
 				}
			}
		}
	}
}

function noData(obj) {
    removePlugins();
}

/**
*   @private
**/
function connectInitial()
{
	for (var i = 0; i < connections.length; i++) 
	{
		var tempConnection = connections[i];

		var tempSocket = createSocketObject(tempConnection.devices, tempConnection.ip, tempConnection.port, tempConnection.led);
		tempSocket.url = "ws://" + tempSocket.ip + ':' + tempSocket.port + "/"; 
//		var tempSocket = createSocketObject(tempConnection.devices, document.location.hostname, tempConnection.port, tempConnection.led);
//		tempSocket.url = "ws://" + document.location.hostname + ':' + tempSocket.port + "/"; 
		socketList.push(tempSocket);
		connect(tempSocket.url);
	}

}

String.prototype.endsWith = function(str)
{
    var lastIndex = this.lastIndexOf(str);
    return (lastIndex !== -1) && (lastIndex + str.length === this.length);
}

/**
*   Socket object must already be in the socketList when this function is called.
*   @private
**/ 
var decode;
function connect(url)
{
	console.log(timeStamp() + "  Connect to " + url + "++++++++++++++++++++");
	for (var j = 0; j < socketList.length; j++) {
		var tempObj = socketList[j];
		if (tempObj.url == url) 
		{
			if (!tempObj.connecting)
			{
				var msgBuffer = "";
				var endsWithNewline = false;
				tempObj.socket = new WebSocket(tempObj.url, 'base64');
				tempObj.socket.connecting = true;

				tempObj.socket.onopen = function(e) { 
					tempObj.socket.connecting = false;
					updateConnected(e.target.url, true);
					console.log(e.target.url);
					tempObj.startTimer();
					console.log("Socket Open " + e.target.url);

				}
				tempObj.socket.onmessage = function (e) {
				    var time1 = performance.now();
					clearTimeout(tempObj.timeoutID);
					tempObj.timeoutID = null;
					tempObj.startTimer();
					decode = window.atob(e.data);
					// Check for multiple packets in message
					msgBuffer += decode;
					// Look for the end of text character as the message terminator
					endsWithNewline = msgBuffer.endsWith("\x03");
					if (msgBuffer.indexOf("\x03") >= 0) 
					{
						var newMessages = msgBuffer.split("\x03");
						for (var i=0; i < newMessages.length; i++)
						{
							if (i <  newMessages.length - 1)
							{
								if (newMessages[i].length > 0)
								{
//									console.log("Found Embedded New Message:" + newMessages[i]);
									messageHandler(newMessages[i]);
								}
							}
							else
							{
								if (endsWithNewline)
								{
									if (newMessages[i].length > 0)
									{
//										console.log("Found New Message:" + newMessages[i]);
										messageHandler(newMessages[i]);
									}
									msgBuffer = "";
								}
								else
								{
									msgBuffer = newMessages[i];
								}
							}
						}
					}
					var time2 = performance.now();
					//console.log("Receiving message took " + (time2 - time1));
				}
				tempObj.socket.onclose = function(e) {
					clearTimeout(tempObj.timeoutID);
					tempObj.timeoutID = null;
					updateConnected(e.target.url, false);
					tempObj.socket.connecting = false;
//					console.log("Socket Closing - " + e.data + " " + e.target.url);
				}
				tempObj.socket.onerror = function(e) {
					clearTimeout(tempObj.timeoutID);
					tempObj.timeoutID = null;

					updateConnected(e.target.url, false);
					tempObj.socket.connecting = false;
//					console.log("Socket Error - " + e.data + " " + e.target.url);
				}		
			}
			else {
//				log(tempObj.url + " Already trying to connect --------------- connecting");
			}
		}
	}
}


function round(value, decimals) {
    return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}

function removeClassMatch(div, matchStr) {
	var reg = new RegExp("(^|\\s)"+matchStr+"\\S+", 'gi');
	div.removeClass (function (index, className, reg) {
    	return (className.match (reg || []).join(' '));
//    return (className.match (/(^|\s)z-index-\S+/g) || []).join(' ');
 //   ~'foo'.indexOf('oo')
});
}

/**
 * jQuery alterClass plugin
 *
 * Remove element classes with wildcard matching. Optionally add classes:
 *   $( '#foo' ).alterClass( 'foo-* bar-*', 'foobar' )
 *
 * Copyright (c) 2011 Pete Boere (the-echoplex.net)
 * Free under terms of the MIT license: http://www.opensource.org/licenses/mit-license.php
 *
 */
(function ( $ ) {
	
$.fn.alterClass = function ( removals, additions ) {
	
	var self = this;
	
	if ( removals.indexOf( '*' ) === -1 ) {
		// Use native jQuery methods if there is no wildcard matching
		self.removeClass( removals );
		return !additions ? self : self.addClass( additions );
	}

	var patt = new RegExp( '\\s' + 
			removals.
				replace( /\*/g, '[A-Za-z0-9-_]+' ).
				split( ' ' ).
				join( '\\s|\\s' ) + 
			'\\s', 'g' );

	self.each( function ( i, it ) {
		var cn = ' ' + it.className + ' ';
		while ( patt.test( cn ) ) {
			cn = cn.replace( patt, ' ' );
		}
		it.className = $.trim( cn );
	});

	return !additions ? self : self.addClass( additions );
};

})( jQuery );

// ------------------- AUDIO Utilities ------------------------


function startSoundTimer(duration)
{
    SoundTimerID = setTimeout(SoundTimeout, duration);
}

function restartSoundTimeout()
{
    stopSoundTimer();
    startSoundTimer(defaultSoundTimeout);
}

function stopSoundTimer()
{
    if (SoundTimerID != null)
    {
        clearTimeout(SoundTimerID);
        SoundTimerID = null;
    }    
}
function SoundTimeout()
{
    console.log("Sound Timeout Clearing");
    currentAudio = -1;
}

function preloadAudio(url) {
    var audio = new Audio();
    audio.src = url;
    audio.preload = "auto";
}

var player = document.getElementById('player');
function playAudio(index, audioFiles) {
    console.log("Playing Audio index:" + index + " Current Audio:" + currentAudio);
    if (soundNotification)
    {
        if (index != currentAudio)
        {
            currentAudio = index;
            stopAudio();
            player.src = audioFiles[index];
            player.playbackRate = 1.0;
            player.play();

            restartSoundTimeout(defaultSoundTimeout);
			hisAudio.payload.Id = generateUUID();
            hisAudio.payload.HISPostState = audioFiles[index];
            sendCommand("TEST;" + JSON.stringify(hisAudio));
        }
    }
}

function stopAudio()
{
    player.pause();
    player.currentTime = 0;
}

$(document).ready(function () {

    if (document.getElementById('server') != null) {
        document.getElementById('server').innerHTML = connections[0].ip;
    }

    if (document.getElementById('port') != null) {
        document.getElementById('port').innerHTML = connections[0].port;
    }

    $('#messagesTable').DataTable();
    $('#eventLogTable').DataTable();


    // TODO: Need to transition this to use real telemetry
//    handleStatusMessage(stateJson["payload"]);


    /*
    var statusKeys = Object.keys(json["payload"]);
    console.log(statusKeys);
    for (var i = 0; i < statusKeys.length; i++) {
        UpdatePluginWithStatus(statusKeys[i], stateJson["payload"][statusKeys[i]]);
    }
    */
    connectInitial();

});


// jquery UI initialization
$( function() {
   $( "#tabs" ).tabs();
} );

$( function() {
    $('input[type="checkbox"]').checkboxradio();
} );

$( function() {
    $( ".widget input[type=submit], .widget a, .widget button" ).button();
    $( "button, input, a" ).click( function( event ) {
        event.preventDefault();
    } );
} );
